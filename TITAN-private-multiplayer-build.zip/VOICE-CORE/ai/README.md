# VoiceCore Speech AI

Local, offline phrase recovery for THE TITAN voice integration.

## Purpose
- Identify spoken words more reliably (ASR confusions, phonetics)
- Re-rank Web Speech API alternatives
- Fuzzy-match toward registered Titan commands efficiently

## Files
- `speech-ai.js` — enhancer used by CommandInterpreter + ExecutionEngine

## Load order
Must load after `command-registry.js` and before `command-interpreter.js`.

## API
```js
VoiceCore.SpeechAI.enhance(textOrAlts)  // { primary, candidates, repaired }
VoiceCore.SpeechAI.enhanceList(textOrAlts) // string[]
VoiceCore.SpeechAI.rebuildIndex()
VoiceCore.SpeechAI.stats()
```

No network calls. Runs entirely in the browser.
