/**
 * VoiceCore — Execution Engine (v2)
 * Matches recognised text (or multiple hypotheses) → registered command → runs action + speaks response.
 */
(function (global) {
  "use strict";

  const ExecutionEngine = {
    history: [],          // { text, commandName, timestamp, success, score }
    maxHistory: 50,
    pendingConfirm: null, // { command, resolve }
    currentContext: null,
    onCommand: null,
    onUnknown: null,

    setContext(ctx) {
      this.currentContext = ctx || null;
    },

    /**
     * Process final recognised transcript(s).
     * @param {string|string[]} textOrAlts  Best text, or array of alternative transcripts
     * @returns {Promise<{ok:boolean, command?:object, message?:string, score?:number}>}
     */
    async process(textOrAlts) {
      const Registry = global.VoiceCore && global.VoiceCore.CommandRegistry;
      const Response = global.VoiceCore && global.VoiceCore.VoiceResponse;
      if (!Registry) return { ok: false, message: "Registry not loaded" };

      const primary = Array.isArray(textOrAlts)
        ? (textOrAlts[0] || "")
        : String(textOrAlts || "");
      const cleaned = primary.trim();
      if (!cleaned && !(Array.isArray(textOrAlts) && textOrAlts.length)) {
        return { ok: false, message: "Empty" };
      }

      // Handle pending confirmation first (use primary text)
      if (this.pendingConfirm) {
        const lower = cleaned.toLowerCase();
        if (/\b(yes|yeah|yep|yup|confirm|do it|proceed|ok|okay|sure|affirmative)\b/.test(lower)) {
          const cmd = this.pendingConfirm.command;
          this.pendingConfirm = null;
          return this._execute(cmd, cleaned, 1.0);
        }
        if (/\b(no|nope|nah|cancel|stop|abort|don't|do not|negative)\b/.test(lower)) {
          this.pendingConfirm = null;
          if (Response) await Response.speak("Cancelled.");
          return { ok: false, message: "Cancelled by user" };
        }
        if (Response) await Response.speak("Please say yes or no.");
        return { ok: false, message: "Awaiting confirmation" };
      }

      // Speech AI: repair + re-rank hypotheses before registry match
      let payload = textOrAlts;
      try {
        const AI = global.VoiceCore && global.VoiceCore.SpeechAI;
        if (AI && typeof AI.enhanceList === "function") {
          payload = AI.enhanceList(textOrAlts);
          if (payload && payload[0]) cleaned = payload[0];
        }
      } catch (_) {}

      // Multi-hypothesis match
      const match = Registry.match(payload, this.currentContext);
      if (!match) {
        this._pushHistory(cleaned, null, false, 0);
        if (this.onUnknown) this.onUnknown(cleaned);
        if (Response) await Response.error("Command not recognised.");
        return { ok: false, message: "No match", text: cleaned };
      }

      const cmd = match.command;

      if (cmd.confirm) {
        this.pendingConfirm = { command: cmd };
        const q = typeof cmd.response === "function"
          ? "Are you sure?"
          : `Confirm: ${cmd.phrases[0]}? Say yes or no.`;
        if (Response) await Response.speak(q);
        return { ok: false, message: "Confirmation required", command: cmd, score: match.score };
      }

      return this._execute(cmd, cleaned, match.score);
    },

    async _execute(cmd, originalText, score) {
      const Response = global.VoiceCore && global.VoiceCore.VoiceResponse;
      let success = true;
      let errMsg = null;
      try {
        await Promise.resolve(cmd.action());
      } catch (err) {
        success = false;
        errMsg = err && err.message ? err.message : String(err);
        console.error("[VoiceCore] Action error:", err);
      }

      this._pushHistory(originalText, cmd.name, success, score || 0);

      if (success) {
        let reply = null;
        if (typeof cmd.response === "function") {
          try { reply = cmd.response(); } catch (_) {}
        } else if (typeof cmd.response === "string") {
          reply = cmd.response;
        }
        if (reply && Response) await Response.speak(reply);
      } else if (Response) {
        await Response.speak("There was a problem executing that command.");
      }

      const result = {
        ok: success,
        command: cmd,
        text: originalText,
        error: errMsg,
        score: score || 0
      };
      if (this.onCommand) this.onCommand(result);
      return result;
    },

    _pushHistory(text, name, success, score) {
      this.history.unshift({
        text,
        commandName: name,
        success,
        score: score || 0,
        timestamp: Date.now()
      });
      if (this.history.length > this.maxHistory) this.history.length = this.maxHistory;
    },

    getHistory() {
      return this.history.slice();
    },

    clearHistory() {
      this.history = [];
    }
  };

  global.VoiceCore = global.VoiceCore || {};
  global.VoiceCore.ExecutionEngine = ExecutionEngine;
})(typeof window !== "undefined" ? window : globalThis);
