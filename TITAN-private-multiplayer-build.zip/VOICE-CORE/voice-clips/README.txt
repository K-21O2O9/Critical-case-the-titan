BRAVE voice-clip overrides
==========================

Drop audio files here named exactly after a FILE STEM in Brave-Speech-Lines.pdf.

Examples:
  activation.mp3
  brave_online.opus
  motor_one_feed_on.wav
  navigation_map_displayed.ogg

Supported: .mp3 .opus .ogg .wav .m4a .webm

Behavior:
  - If a matching file is found for a spoken line, that file plays instead of TTS.
  - Only matching lines are replaced; everything else still uses the assistant voice.
  - Folder may be empty; overrides are optional.

This folder is linked at runtime from VOICE-CORE/js/voice-response.js
(base path: VOICE-CORE/voice-clips/).
