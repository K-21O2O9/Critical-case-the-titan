/**
 * VoiceCore — User settings (localStorage)
 */
(function (global) {
  "use strict";

  const STORAGE_KEY = "voicecore-settings-v1";

  const Settings = {
    defaults: {
      enabled: true,
      voiceFeedback: true,
      continuous: true,
      lang: "en-US",
      wakePhrase: "",          // empty = always listening when activated
      confirmDestructive: true
    },

    data: null,

    load() {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        this.data = raw ? { ...this.defaults, ...JSON.parse(raw) } : { ...this.defaults };
      } catch (_) {
        this.data = { ...this.defaults };
      }
      return this.data;
    },

    save() {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
      } catch (_) {}
    },

    get(key) {
      if (!this.data) this.load();
      return this.data[key];
    },

    set(key, value) {
      if (!this.data) this.load();
      this.data[key] = value;
      this.save();
    },

    reset() {
      this.data = { ...this.defaults };
      this.save();
    }
  };

  global.VoiceCore = global.VoiceCore || {};
  global.VoiceCore.Settings = Settings;
})(typeof window !== "undefined" ? window : globalThis);
